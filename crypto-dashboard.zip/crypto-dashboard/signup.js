const signupForm = document.getElementById("signupForm");

signupForm.addEventListener("submit", function(e){

  e.preventDefault();

  const name = document.getElementById("signupName").value;
  const email = document.getElementById("signupEmail").value;
  const password = document.getElementById("signupPassword").value;

  localStorage.setItem("userName", name);
  localStorage.setItem("userEmail", email);
  localStorage.setItem("userPassword", password);

  alert("Account Created Successfully");

  window.location.href = "login.html";

});