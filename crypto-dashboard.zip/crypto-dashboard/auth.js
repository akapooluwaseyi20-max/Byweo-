/* ELEMENTS */

const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");

const showSignup = document.getElementById("showSignup");
const showLogin = document.getElementById("showLogin");

const showLoginText = document.getElementById("showLoginText");

/* SWITCH TO SIGNUP */

showSignup.addEventListener("click", function(){

  loginForm.classList.add("hidden");

  signupForm.classList.remove("hidden");

  showSignup.parentElement.classList.add("hidden");

  showLoginText.classList.remove("hidden");

});

/* SWITCH TO LOGIN */

showLogin.addEventListener("click", function(){

  signupForm.classList.add("hidden");

  loginForm.classList.remove("hidden");

  showLoginText.classList.add("hidden");

  showSignup.parentElement.classList.remove("hidden");

});

/* SIGNUP */

signupForm.addEventListener("submit", function(e){

  e.preventDefault();

  const name = document.getElementById("signupName").value;
  const email = document.getElementById("signupEmail").value;
  const password = document.getElementById("signupPassword").value;

  /* SAVE USER */

  localStorage.setItem("userName", name);
  localStorage.setItem("userEmail", email);
  localStorage.setItem("userPassword", password);

  alert("Account Created Successfully");

  signupForm.reset();

});

/* LOGIN */

loginForm.addEventListener("submit", function(e){

  e.preventDefault();

  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const savedEmail = localStorage.getItem("userEmail");
  const savedPassword = localStorage.getItem("userPassword");

  if(email === savedEmail && password === savedPassword){

    alert("Login Successful");

    window.location.href = "index.html";

  }else{

    alert("Invalid Email or Password");

  }

});