console.log("Crypto Dashboard Loaded");

/* =========================
   LIVE BTC PRICE
========================= */

async function getBTCPrice() {

  try {

    const response = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"
    );

    const data = await response.json();

    const btcPrice = data.bitcoin.usd;

    document.getElementById("btc-price").innerText =
      "$" + btcPrice.toLocaleString();

  } catch (error) {

    console.log("Error fetching BTC price:", error);

  }

}

getBTCPrice();

/* =========================
   BUTTON FUNCTIONS
========================= */

/* LOGOUT BUTTON */

const logoutBtn = document.querySelector(".logout");

logoutBtn.addEventListener("click", function () {

  alert("Logged Out Successfully");

});

/* DEPOSIT BUTTON */

const depositBtn = document.querySelector(".actions button:first-child");

depositBtn.addEventListener("click", function () {

  const amount = prompt("Enter Deposit Amount:");

  if (amount && amount > 0) {

    alert("$" + amount + " Deposited Successfully");

  } else {

    alert("Invalid Amount");

  }

});

/* TRANSFER BUTTON */

const transferBtn = document.querySelector(".actions button:last-child");

transferBtn.addEventListener("click", function () {

  const wallet = prompt("Enter Wallet Address:");

  if (wallet) {

    const amount = prompt("Enter Amount to Transfer:");

    if (amount && amount > 0) {

      alert(
        "$" + amount +
        " Sent Successfully to:\n" +
        wallet
      );

    } else {

      alert("Invalid Amount");

    }

  } else {

    alert("Wallet Address Required");

  }

});

/* =========================
   SIDEBAR MENU
========================= */

const menuItems = document.querySelectorAll(".sidebar li");

menuItems.forEach(item => {

  item.addEventListener("click", function () {

    /* REMOVE ACTIVE CLASS */
    menuItems.forEach(i => i.classList.remove("active"));

    /* ADD ACTIVE CLASS */
    this.classList.add("active");

    /* SHOW ALERT */
    alert(this.innerText.trim() + " Page Opened");

  });

});

/* =========================
   SEARCH FUNCTION
========================= */

const searchInput = document.querySelector(".search-box input");

searchInput.addEventListener("keyup", function () {

  console.log("Searching:", this.value);

});

/* =========================
   STAT BOX CLICK
========================= */

const statBoxes = document.querySelectorAll(".stat-box");

statBoxes.forEach(box => {

  box.addEventListener("click", function () {

    alert(
      this.innerText.trim()
    );

  });

});