const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", function(e){

  e.preventDefault();

  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const savedEmail = localStorage.getItem("userEmail");
  const savedPassword = localStorage.getItem("userPassword");

  if(email === savedEmail && password === savedPassword){

    alert("Login Successful");

    window.location.href = "index.html";

  }else{

    alert("Invalid Email or Password");

  }

});